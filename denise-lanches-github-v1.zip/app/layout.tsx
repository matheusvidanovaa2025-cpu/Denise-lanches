import type { Metadata, Viewport } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title:"Denise Lanches",
  description:"Cardápio digital e pedidos online"
};
export const viewport: Viewport = {
  width:"device-width", initialScale:1, viewportFit:"cover", themeColor:"#070707"
};
export default function RootLayout({children}:{children:React.ReactNode}){
  return <html lang="pt-BR"><body>{children}</body></html>;
}